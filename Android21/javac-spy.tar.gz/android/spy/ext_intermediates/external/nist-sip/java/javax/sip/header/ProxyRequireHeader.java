package javax.sip.header;

public interface ProxyRequireHeader extends RequireHeader {
    String NAME = "Proxy-Require";
}
